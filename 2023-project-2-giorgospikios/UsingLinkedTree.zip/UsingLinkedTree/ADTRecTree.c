///////////////////////////////////////////////////////////////////
//
// Υλοποίηση του ADT RecTree μέσω links
//
///////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include "ADTRecTree.h"


// Προς υλοποίηση...


//  Ένα δέντρο είναι pointer σε αυτό το struct
struct rec_tree {
	
	Pointer value; 	// To στοιχείο που περιέχει η ρίζα του δέντρου
	RecTree left;	// To αριστερό υποδέντρο
	RecTree right;	// To δεξί υποδέντρο

};


// Δημιουργεί και επιστρέφει ένα νέο δέντρο, με τιμή (στη ρίζα) value και υποδέντρα left και right.

RecTree rectree_create(Pointer value, RecTree left, RecTree right) {
	
	// Δημιουργία δέντρου που θα επιστρεφει
	RecTree tree=malloc(sizeof(struct rec_tree));
	
	// Εκχώρηση τιμής ρίζας, αριστερού υποδέντρου και δεξιού υποδέντρου
	tree->value=value;
	tree->left=left;
	tree->right=right;
	
	// Επιστροφή δέντρου
	return tree;
}

// Επιστρέφει τον αριθμό στοιχείων που περιέχει το δέντρο.

int rectree_size(RecTree tree) {
	
	// Αν το δέντρο είναι κενό επιστρέφει 0
	if(tree==NULL)
		return 0;
	
	// Διαφορετικά επιστρέφει το άθροισμα των κόμβων των υποδέντρων του συν 1
	// (το 1 αντιστοιχεί στο στοιχείο που περιέχει το ίδιο)	
	return rectree_size(tree->left)+rectree_size(tree->right)+1;
	
}

// Ελευθερώνει όλη τη μνήμη που δεσμεύει το δέντρο tree.

void rectree_destroy(RecTree tree) {
	
	// Εαν το δέντρο είναι
	if(tree==NULL)
		return;
	
	// Eάν υπάρχει αριστερό υποδέντρο...
	if(tree->left!=NULL){
		
		//...καταστρέφεται η μνήμη που έχει δεσμεύσει...
		rectree_destroy(tree->left);
		
		// ...και στη συνέχεια καταστρέφεται και το ίδιο.
		free(tree->left);		
		
	}
	
	// Eάν right δεξιό υποδέντρο...
	if(tree->left!=NULL){
		
		//...καταστρέφεται η μνήμη που έχει δεσμεύσει...
		rectree_destroy(tree->right);
		
		// ...και στη συνέχεια καταστρέφεται και το ίδιο.
		free(tree->right);		
		
	}
	
	// Τελος καταστρέφεται η μνήμη του στοιχειου που περιέχει η ρίζα 
	free(tree->value);	
	
	tree->value=NULL;
	tree->left=NULL;
	tree->right=NULL;
	
}

// Επιστρέφουν την τιμή (στη ρίζα), το αριστερό και το δεξί υποδέντρο του δέντρου tree.

RecTree rectree_left(RecTree tree) {
		
	// Αν το δέντρο είναι κενό επιστρέφεται NULL
	if(tree==NULL)
		return NULL;
	
	// Διαφορετικά επιστρέφεται το αριστερό υποδέντρο
	return tree->left;
	
}

Pointer rectree_value(RecTree tree) {
	
	// Αν το δέντρο είναι κενό επιστρέφεται NULL
	if(tree==NULL)
		return NULL;
	
	// Διαφορετικά επιστρέφεται η τιμή της ρίζας
	return (Pointer)(unsigned long int)(*((int*)(tree->value)));
	
}

RecTree rectree_right(RecTree tree) {
	
	// Αν το δέντρο είναι κενό επιστρέφεται NULL
	if(tree==NULL)
		return NULL;
	
	// Διαφορετικά επιστρέφεται το δεξί υποδέντρο
	return tree->right;
	
}

