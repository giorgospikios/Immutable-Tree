#include "ADTRecTree_utils.h"

// Επιστρέφει το υποδέντρο του tree στη θέση pos. Η αρίθμηση των θέσεων ξεκινάει
// από το 0 (ρίζα) και κινείται κατά επίπεδα, τα παιδιά της ρίζας έχουν θέση 1
// και 2, τα δικά τους παιδιά έχουν θέσεις 3,4,5,6, κλπ. Αν το υποδέντρο δεν
// υπάρχει θα επιστρέφεται REC_TREE_EMPTY. 

RecTree rectree_get_subtree(RecTree tree, int pos){
	
	// Aρχικά υπολογίζεται το επίπεδο της θέσης 
	int level;
	
	// Οι κόμβοι στο τελευταίο επίπεδο ενός πληρους δέντρου επιπέδου ίσου με τη μεταβλητή level.
	int last_level_tree_nodes;
	
	// Οι κόμβοι ενός πληρους δέντρου επιπέδου ίσου με τη μεταβλητή level.
	int num_of_full_tree_nodes;
	
	// Mονοπάτι διαδρομής εύρεσης κόμβου τηξς θέσης pos
	int* path_array;
	
	// Βοηθητική μεταβλητή
	int i;
	
	// Το δέντρο που επιστρεφεται
	RecTree ret_tree;
		
	// Αρχικοποίηση των μεταβλητών 
	level=0;
	last_level_tree_nodes=0;
	num_of_full_tree_nodes=0;
	
	// Aν το δέντρο είναι κενό επιστρέφεται REC_TREE_EMPTY
	if(tree==REC_TREE_EMPTY)
		return REC_TREE_EMPTY;
	
	// Aν η θέση είναι μικρότερη του μηδενός επιστρέφεται REC_TREE_EMPTY
	if(pos<0)
		return REC_TREE_EMPTY;
	
	// Περίπτωση που το δέντρο δεν είναι κενό.
	
	// Αν pos=0 απλά επιστρέφεται το ίδιο το δέντρο
	if(pos==0)
		return tree;
	
	
	level=1;
	last_level_tree_nodes=1;
	num_of_full_tree_nodes+=last_level_tree_nodes;
	
	// Υπολογίζεται το επίπεδο που περιέχει τη θέση
	while(num_of_full_tree_nodes<pos+1){
		
		level++;
		last_level_tree_nodes*=2;
		num_of_full_tree_nodes+=last_level_tree_nodes;
		
	}
	
	// Υπολογίζεται η διαδρομή 
	path_array=malloc((level-1)*sizeof(int));

	i=level-2;
	
	while(i>=0){
		path_array[i]=(pos-1)%2;
		pos=(pos-1)/2;
		i--;
	}
		
	ret_tree=tree;
	for(i=0;i<level-1;i++){
		
		if(path_array[i]==0)
			ret_tree=rectree_left(ret_tree);
		else
			ret_tree=rectree_right(ret_tree);
		
		// Σε περίπτωση που η διάτρεξη βγαίνει εκτός δέντρου, επιστρέφεται REC_TREE_EMPTY
		if(ret_tree==REC_TREE_EMPTY){
			
			// Απελευθερώνεται ο πίνακας της διαδρομής
			free(path_array);	
			
			return REC_TREE_EMPTY;
		}
		
	}
	
	// Απελευθερώνεται ο πίνακας της διαδρομής
	free(path_array);
	
	// Επιστρέφεται το δέντρο
	return ret_tree;
	
}

// Δημιουργεί και επιστρέφει ένα νέο δέντρο, το οποίο προκύπτει αντικαθιστώντας
// το υποδέντρο του tree στη θέση pos με το subtree που δίνεται.  Η θέση pos
// πρέπει να αντιστοιχεί είτε σε υπάρχον κόμβο (που αντικαθίσταται), είτε στο
// κενό παιδί ενός υπάρχοντος κόμβου (οπότε προστίθεται εκεί το subtree).  Αν το
// subtree τοποθετείται στη ρίζα (pos == 0) τότε επιστρέφεται το ίδιο το subtree.
//
// Η συνάρτηση καταστρέφει αυτόματα τόσο το παλιό υποδέντρο που αντικαθίσταται
// (αν υπάρχει), καθώς και όλους τους προγόνους του που μεταβάλλονται (οπότε
// ξαναδημιουργούνται).

RecTree rectree_replace_subtree(RecTree tree, int pos, RecTree subtree){
	
	// Θέση γονιού
	int parent_pos;
	
	// Θέση παππού
	int grandparent_pos;
	
	// Προσωρινός κόμβος-δεντρο
	RecTree temp;
	
	// Νέος κόμβος-παππούς
	RecTree new_grandparent;
	
	// Νέος κόμβος-γονιός
	RecTree new_parent;
	
	int* ptr;
	
	// Περίπτωση αντικατάστασης ρίζας. 
	// Απλά καταστρέφεται το δέντρο αν υπάρχει και επιστρέφεται το subtree
	if(pos==0){
		
		if(tree!=REC_TREE_EMPTY){
			
			rectree_destroy(tree);	
			free(tree);
			
		}		
		
		return subtree;			
	}
	
	// Υπολογισμός θέσης γονιού
	parent_pos=(pos-1)/2;
	
	// Υπολογισμός θέσης παππού
	grandparent_pos=(parent_pos-1)/2;

	// Αν δεν υπάρχει ο γονιος επιστρεφεται REC_TREE_EMPTY
	if(rectree_get_subtree(tree,parent_pos)==REC_TREE_EMPTY)
		return REC_TREE_EMPTY;	
	
	// Περίπτωση στην οποία δεν υπάρχει παππούς
	if(parent_pos==0){
		
		// O παλιος γονιός σώζεται πριν την καταστροφή του 
		temp=tree;
		
		// Περίπτωση αντικατάστασης δεξιού υποδέντρου 
		if(2*parent_pos+2==pos){
			
			tree=rectree_create(rectree_value(temp),rectree_left(temp),subtree);
			
			// Καταστροφή του δέντρου που αντικαταστάθηκε και του παλιού γονιού 
			rectree_destroy(rectree_right(temp));
			rectree_destroy(temp);
			free(temp);
			
			return tree;
			
		}
		// Περίπτωση αντικατάστασης αριστερού υποδέντρου 
		else{
			
			tree=rectree_create(rectree_value(temp),subtree,rectree_right(temp));
			
			// Καταστροφή του δέντρου που αντικαταστάθηκε και του παλιού γονιού 
			rectree_destroy(rectree_left(temp));
			rectree_destroy(temp);
			free(temp);
			
			return tree;			
			
		}
		
	}
	
	// Περίπτωση στην οποία υπάρχει παππούς

	// O παλιος γονιός σώζεται πριν την καταστροφή του 
	temp=rectree_get_subtree(tree,parent_pos);

	// Περίπτωση αντικατάστασης δεξιού υποδέντρου 
	if(2*parent_pos+2==pos){
			
		ptr=malloc(sizeof(int));
		*ptr=(unsigned long int)rectree_value(temp);
		
		new_parent=rectree_create(ptr,rectree_left(temp),subtree);
		
		// Αν υπήρχε δεξιό παιδι καταστρεφεται 
		if(rectree_right(temp)!=REC_TREE_EMPTY)
			rectree_destroy(rectree_right(temp));
		
	}
	// Περίπτωση αντικατάστασης αριστερού υποδέντρου 
	else{		
		
		ptr=malloc(sizeof(int));
		*ptr=(unsigned long int)rectree_value(temp);
		
		new_parent=rectree_create(ptr,subtree,rectree_right(temp));	
		
		// Αν υπήρχε αριστερό παιδι καταστρεφεται 
		if(rectree_left(temp)!=REC_TREE_EMPTY)
			rectree_destroy(rectree_left(temp));
		
	}
	
	// Καταστρεφεται ο παλιός κόμβος γονιός
	free(temp);
		
	
	// Μεχρι να φτασουμε στη ρίζα διαγραφουμε τους προγόνους και φτιάχνουμε νέους
	while(parent_pos!=0){
		
		// O παλιος παππούς σώζεται πριν την καταστροφή του 
		temp=rectree_get_subtree(tree,grandparent_pos);

		// Περίπτωση αντικατάστασης δεξιού υποδέντρου 
		if(2*grandparent_pos==parent_pos){
			
			ptr=malloc(sizeof(int));
			*ptr=(unsigned long int)rectree_value(temp);
			
			new_grandparent=rectree_create(ptr,rectree_left(temp),new_parent);
			
			
		}
		// Περίπτωση αντικατάστασης αριστερού υποδέντρου 
		else{		
			
			ptr=malloc(sizeof(int));
			*ptr=(unsigned long int)rectree_value(temp);
			
			new_grandparent=rectree_create(ptr,new_parent,rectree_right(temp));	
			
		}
		
		// Καταστρεφεται ο παλιός κόμβος παππους
		free(temp);
		
		// Ο παππους γίνεται γονιός 
		new_parent=new_grandparent;
		parent_pos=grandparent_pos;
		
		// Υπολογίζεται η θέση του νέου παππού 
		grandparent_pos=(parent_pos-1)/2;
		
	}
	
	// Επιστρεφουμε τον γονιό ως νέα ρίζα
	return new_parent;
	
}